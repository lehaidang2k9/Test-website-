<?php
require_once 'config.php';

if (!isset($_GET['id'])) {
    die("Thiếu mã tệp tin.");
}

$uuid = $_GET['id'];
// Tối ưu: Chỉ lấy những cột thực sự cần thiết để giảm tải DB
$stmt = $pdo->prepare("SELECT stored_name, original_name, mime_type, file_size FROM files WHERE uuid = ?");
$stmt->execute([$uuid]);
$file = $stmt->fetch();

if (!$file) {
    die("Tệp tin không tồn tại.");
}

$file_url = 'uploads/' . $file['stored_name'];

function formatSize($bytes) {
    if ($bytes <= 0) return '0 B';
    $base = log($bytes, 1024);
    $suffixes = array('B', 'KB', 'MB', 'GB');
    return round(pow(1024, $base - floor($base)), 1) . ' ' . $suffixes[floor($base)];
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Tải về - Hải Đăng</title>
    <style>
        :root {
            --primary: #8b5cf6;
            --bg: #050508;
            --card-bg: #111118;
            --border: rgba(255, 255, 255, 0.1);
            --text: #ffffff;
            --text-dim: #999;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, sans-serif; }
        body { background: var(--bg); color: var(--text); }
        .container { width: 100%; max-width: 400px; margin: 0 auto; padding: 20px; }

        .btn-back { 
            display: inline-block; color: var(--text); text-decoration: none; 
            font-size: 13px; margin-bottom: 20px; padding: 8px 15px; 
            background: var(--card-bg); border: 1px solid var(--border); border-radius: 8px;
        }

        .download-card { 
            background: var(--card-bg); border: 1px solid var(--border); 
            border-radius: 20px; padding: 30px 20px; text-align: center; 
        }

        .file-icon { font-size: 50px; margin-bottom: 15px; display: block; }
        
        .file-name { 
            font-size: 16px; font-weight: bold; margin-bottom: 5px; 
            word-break: break-all; color: #fff;
        }
        
        .file-meta { font-size: 12px; color: var(--text-dim); margin-bottom: 25px; }

        .btn-download { 
            display: block; width: 100%; background: var(--primary); 
            color: white; text-decoration: none; text-align: center; 
            padding: 15px; border-radius: 12px; font-weight: bold; 
            font-size: 16px; box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);
        }

        .tip { font-size: 11px; color: var(--text-dim); margin-top: 15px; }
    </style>
</head>
<body>

<div class="container">
    <a href="index.php" class="btn-back">← Quay lại</a>

    <div class="download-card">
        <span class="file-icon">
            <?php 
                if (strpos($file['mime_type'], 'video/') === 0) echo '🎬';
                elseif (strpos($file['mime_type'], 'image/') === 0) echo '🖼️';
                else echo '📁';
            ?>
        </span>
        
        <div class="file-name"><?= htmlspecialchars($file['original_name']) ?></div>
        <div class="file-meta">
            Dung lượng: <?= formatSize($file['file_size']) ?> • 
            <?= strtoupper(explode('/', $file['mime_type'])[1]) ?>
        </div>

        <a href="<?= $file_url ?>" download="<?= htmlspecialchars($file['original_name']) ?>" class="btn-download">
            NHẤN ĐỂ TẢI XUỐNG
        </a>
        
        <p class="tip">Tệp tin đã sẵn sàng để tải về máy của bạn.</p>
    </div>
</div>

</body>
</html>
