<?php
require_once 'config.php';
// Không gọi session_start() ở đây vì config.php đã có rồi

// 1. XỬ LÝ ĐĂNG XUẤT NGAY ĐẦU FILE
if (isset($_GET['logout'])) {
    $_SESSION = array(); // Xóa sạch mảng session
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    session_destroy(); // Hủy session
    header("Location: auth.php"); // Quay lại trang login
    exit;
}

$msg = ''; $type = ''; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $user = trim($_POST['username'] ?? '');
    $pass = $_POST['password'] ?? '';

    if ($action === 'register') {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->execute([$user, $hash]);
            $msg = "Đăng ký thành công!"; $type = "success";
        } catch (Exception $e) { $msg = "Tài khoản đã tồn tại!"; $type = "error"; }
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$user]);
        $userData = $stmt->fetch();
        
        if ($userData && password_verify($pass, $userData['password'])) {
            // LÀM SẠCH VÀ NẠP LẠI SESSION
            $_SESSION['user_id'] = $userData['id'];
            $_SESSION['username'] = $userData['username'];
            
            // Lấy avatar từ Database để lưu mãi mãi
            $_SESSION['avatar'] = !empty($userData['avatar']) ? $userData['avatar'] : null;

            $msg = "Đang đăng nhập..."; $type = "success";
            echo "<script>setTimeout(() => { window.location.href='index.php'; }, 800);</script>";
        } else { $msg = "Sai tài khoản/mật khẩu!"; $type = "error"; }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Xác thực - Hải Đăng CloudX</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,400,0,0" />
    <style>
        :root { --primary: #8b5cf6; --bg: #050508; --card-bg: #111118; --border: rgba(255,255,255,0.1); --text: #fff; }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, sans-serif; }
        body { background: var(--bg); color: var(--text); display: flex; align-items: center; justify-content: center; min-height: 100vh; overflow: hidden; }
        #toast-container { position: fixed; top: 20px; right: 20px; z-index: 10000; display: flex; flex-direction: column; gap: 8px; }
        .toast { min-width: 180px; background: rgba(26, 26, 37, 0.9); backdrop-filter: blur(10px); border: 1px solid var(--border); border-left: 3px solid var(--primary); padding: 8px 12px; border-radius: 10px; display: flex; align-items: center; gap: 8px; animation: slideIn 0.4s forwards; }
        .toast.success { border-left-color: #22c55e; }
        .toast.error { border-left-color: #ef4444; }
        @keyframes slideIn { from { transform: translateX(130%); } to { transform: translateX(0); } }
        .auth-card { background: var(--card-bg); border: 1px solid var(--border); padding: 35px 25px; border-radius: 24px; width: 90%; max-width: 340px; text-align: center; }
        h2 { font-size: 24px; margin-bottom: 25px; font-weight: 800; }
        h2 span { color: var(--primary); }
        input { width: 100%; padding: 14px; border-radius: 12px; border: 1px solid var(--border); background: #000; color: #fff; margin-bottom: 15px; outline: none; }
        .btn { width: 100%; padding: 14px; border-radius: 12px; border: none; background: var(--primary); color: #fff; font-weight: bold; cursor: pointer; }
        .toggle { margin-top: 20px; font-size: 12px; color: #777; cursor: pointer; }
        .toggle b { color: var(--primary); }
    </style>
</head>
<body>
<div id="toast-container"></div>
<div class="auth-card">
    <h2>Hải Đăng <span>CloudX</span></h2>
    <form method="POST">
        <input type="hidden" name="action" id="action" value="login">
        <input type="text" name="username" placeholder="Tên đăng nhập" required>
        <input type="password" name="password" placeholder="Mật khẩu" required>
        <button type="submit" class="btn" id="btn">ĐĂNG NHẬP</button>
    </form>
    <div class="toggle" onclick="toggleMode()">Chưa có tài khoản? <b>Đăng ký ngay</b></div>
</div>
<script>
function showNotify(m, t='success') {
    const c = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${t}`;
    toast.innerHTML = `<span>${m}</span>`;
    c.appendChild(toast);
    setTimeout(() => { toast.remove(); }, 2500);
}
<?php if($msg): ?> showNotify("<?= $msg ?>", "<?= $type ?>"); <?php endif; ?>
function toggleMode() {
    const a = document.getElementById('action'), b = document.getElementById('btn'), t = document.querySelector('.toggle');
    a.value = a.value === 'login' ? 'register' : 'login';
    b.innerText = a.value === 'login' ? 'ĐĂNG NHẬP' : 'TẠO TÀI KHOẢN';
    t.innerHTML = a.value === 'login' ? 'Chưa có tài khoản? <b>Đăng ký ngay</b>' : 'Đã có tài khoản? <b>Đăng nhập</b>';
}
</script>
</body>
</html>
