<?php
require_once 'config.php';
// Không gọi session_start() vì config.php đã xử lý

if (!isset($_SESSION['username'])) { header('Location: auth.php'); exit; }
$username = $_SESSION['username'];
$user_id = $_SESSION['user_id'];
$msg = '';

// 1. Xử lý Upload Avatar (Giữ nguyên logic của bạn)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['avatar_file'])) {
    $file = $_FILES['avatar_file'];
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $newName = 'avatar_' . time() . '_' . $username . '.' . $ext;
    if (!is_dir('uploads/avatars')) mkdir('uploads/avatars', 0777, true);
    if (move_uploaded_file($file['tmp_name'], 'uploads/avatars/' . $newName)) {
        $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
        $stmt->execute([$newName, $user_id]);
        $_SESSION['avatar'] = $newName;
        $msg = "Cập nhật thành công!";
    }
}

// 2. Lấy danh sách bạn bè và số lượng
$stmtFriends = $pdo->prepare("
    SELECT u.username, u.avatar 
    FROM friends f 
    JOIN users u ON (f.user_id_1 = u.id OR f.user_id_2 = u.id) 
    WHERE (f.user_id_1 = ? OR f.user_id_2 = ?) 
    AND u.id != ? AND f.status = 'accepted'
");
$stmtFriends->execute([$user_id, $user_id, $user_id]);
$friendsList = $stmtFriends->fetchAll();
$friendCount = count($friendsList);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hồ sơ - <?= htmlspecialchars($username) ?></title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,400,0,0" />
    <style>
        :root { --primary: #8b5cf6; --bg: #050508; --card-bg: #111118; --border: rgba(255,255,255,0.1); --text: #fff; }
        body { background: var(--bg); color: var(--text); font-family: sans-serif; display: flex; justify-content: center; padding: 40px 0; margin: 0; }
        .card { background: var(--card-bg); padding: 30px; border-radius: 24px; width: 90%; max-width: 380px; text-align: center; border: 1px solid var(--border); }
        .back-link { display: flex; align-items: center; justify-content: center; gap: 5px; margin-bottom: 20px; color: var(--primary); text-decoration: none; font-size: 14px; font-weight: bold; }
        .avatar-preview { width: 100px; height: 100px; border-radius: 50%; background: var(--primary); margin: 0 auto 15px; overflow: hidden; display: flex; align-items: center; justify-content: center; font-size: 35px; border: 3px solid var(--primary); box-shadow: 0 8px 15px rgba(139, 92, 246, 0.3); }
        .avatar-preview img { width: 100%; height: 100%; object-fit: cover; }
        
        /* Friend Stats */
        .f-stats { display: flex; justify-content: center; gap: 20px; margin-bottom: 20px; padding: 10px; background: rgba(255,255,255,0.03); border-radius: 15px; }
        .stat-item b { display: block; font-size: 18px; }
        .stat-item span { font-size: 11px; color: #888; text-transform: uppercase; }

        /* Friends List Section */
        .friends-section { text-align: left; margin-top: 25px; border-top: 1px solid var(--border); padding-top: 20px; }
        .friends-section h3 { font-size: 14px; margin-bottom: 15px; color: #aaa; display: flex; align-items: center; gap: 5px; }
        .f-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
        .f-item { text-align: center; }
        .f-av { width: 45px; height: 45px; border-radius: 50%; background: #333; margin: 0 auto 5px; overflow: hidden; border: 1px solid var(--border); display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: bold; }
        .f-av img { width: 100%; height: 100%; object-fit: cover; }
        .f-name { font-size: 9px; color: #ccc; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; width: 100%; }

        input[type="file"] { background: #000; padding: 10px; border-radius: 10px; width: 100%; margin-bottom: 15px; font-size: 12px; border: 1px solid #333; color: #fff; }
        .btn-save { background: var(--primary); color: #fff; border: none; padding: 14px; border-radius: 12px; width: 100%; font-weight: bold; cursor: pointer; }
        .success { color: #22c55e; margin-top: 10px; font-size: 12px; }
    </style>
</head>
<body>
<div class="card">
    <a href="index.php" class="back-link">
        <span class="material-symbols-outlined">arrow_back</span> Quay lại trang chủ
    </a>

    <div class="avatar-preview">
        <?php if(!empty($_SESSION['avatar'])): ?>
            <img src="uploads/avatars/<?= $_SESSION['avatar'] ?>">
        <?php else: ?>
            <?= strtoupper(substr($username, 0, 1)) ?>
        <?php endif; ?>
    </div>

    <h2><?= htmlspecialchars($username) ?></h2>
    
    <div class="f-stats">
        <div class="stat-item">
            <b><?= $friendCount ?></b>
            <span>Bạn bè</span>
        </div>
    </div>
    
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="avatar_file" accept="image/*" required>
        <button type="submit" class="btn-save">CẬP NHẬT ẢNH</button>
    </form>
    <?php if($msg) echo "<div class='success'>$msg</div>"; ?>

    <div class="friends-section">
        <h3><span class="material-symbols-outlined" style="font-size:18px">group</span> Danh sách bạn bè</h3>
        <?php if($friendCount > 0): ?>
            <div class="f-grid">
                <?php foreach($friendsList as $f): ?>
                    <div class="f-item">
                        <div class="f-av">
                            <?php if($f['avatar']): ?>
                                <img src="uploads/avatars/<?= $f['avatar'] ?>">
                            <?php else: ?>
                                <?= strtoupper(substr($f['username'], 0, 1)) ?>
                            <?php endif; ?>
                        </div>
                        <div class="f-name"><?= htmlspecialchars($f['username']) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p style="font-size:12px; color:#555; text-align:center">Chưa có bạn bè nào.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
