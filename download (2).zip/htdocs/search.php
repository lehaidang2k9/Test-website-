<?php
// Bật hiển thị lỗi để nếu có lỗi nó sẽ hiện chữ thay vì hiện trang trắng (Lỗi 500)
ini_set('display_errors', 1);
ini_set('display_errors', 'On');
error_reporting(E_ALL);

require_once 'config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit;
}

$my_id = $_SESSION['user_id'];
$pendingCount = 0;

// Lấy danh sách lời mời (Dùng try-catch để tránh sập trang nếu bảng chưa có)
try {
    $stmt_req = $pdo->prepare("SELECT users.id, users.username, users.avatar FROM friends 
                               JOIN users ON friends.user_id_1 = users.id 
                               WHERE friends.user_id_2 = ? AND friends.status = 'pending'");
    $stmt_req->execute([$my_id]);
    $requests = $stmt_req->fetchAll();
    $pendingCount = count($requests);
} catch (Exception $e) {
    $requests = [];
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Bạn bè — CloudX</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,400,0,0" />
    <style>
        :root { --primary: #8b5cf6; --bg: #050508; --card-bg: #111118; --border: rgba(255, 255, 255, 0.1); --text: #ffffff; --success: #10b981; }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, sans-serif; -webkit-tap-highlight-color: transparent; }
        body { background: var(--bg); color: var(--text); padding: 20px 15px 100px 15px; }
        .container { width: 100%; max-width: 450px; margin: 0 auto; }
        .tabs { display: flex; gap: 10px; margin-bottom: 20px; background: var(--card-bg); padding: 5px; border-radius: 15px; border: 1px solid var(--border); }
        .tab-btn { flex: 1; padding: 12px; border: none; background: transparent; color: #888; border-radius: 10px; font-weight: bold; font-size: 13px; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .tab-btn.active { background: var(--primary); color: #fff; }
        .badge { background: #ff4d4d; color: white; font-size: 10px; padding: 2px 7px; border-radius: 20px; }
        .search-card { background: var(--card-bg); border: 1px solid var(--border); padding: 12px; border-radius: 20px; margin-bottom: 15px; }
        .search-box { position: relative; display: flex; align-items: center; }
        .search-box input { width: 100%; background: rgba(255,255,255,0.05); border: 1px solid var(--border); padding: 12px 15px 12px 45px; border-radius: 15px; color: #fff; outline: none; }
        .search-box i { position: absolute; left: 15px; color: #888; }
        .user-row { display: flex; align-items: center; justify-content: space-between; padding: 12px; background: var(--card-bg); border-radius: 18px; margin-bottom: 10px; border: 1px solid var(--border); }
        .u-info { display: flex; align-items: center; gap: 12px; }
        .u-av { width: 40px; height: 40px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; overflow: hidden; }
        .u-av img { width: 100%; height: 100%; object-fit: cover; }
        .action-btn { border: none; padding: 8px 15px; border-radius: 10px; font-size: 11px; font-weight: 800; cursor: pointer; }
        .btn-main { background: var(--primary); color: white; }
        .nav-bar { position: fixed; bottom: 0; left: 0; right: 0; background: rgba(17,17,24,0.85); backdrop-filter: blur(15px); border-top: 1px solid var(--border); display: flex; justify-content: space-around; padding: 12px 0; }
        .nav-item { color: #888; text-decoration: none; display: flex; flex-direction: column; align-items: center; gap: 4px; }
        .nav-item.active { color: var(--primary); }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
    </style>
</head>
<body>

<nav class="nav-bar">
    <a href="index.php" class="nav-item">
        <span class="material-symbols-outlined">home</span><small>Trang chủ</small>
    </a>
    <a href="search.php" class="nav-item active">
        <span class="material-symbols-outlined">group</span><small>Bạn bè</small>
    </a>
    <a href="profile.php" class="nav-item">
        <span class="material-symbols-outlined">person</span><small>Hồ sơ</small>
    </a>
</nav>

<div class="container">
    <div class="tabs">
        <button class="tab-btn active" onclick="switchTab(event, 'search-tab')">Tìm bạn</button>
        <button class="tab-btn" onclick="switchTab(event, 'req-tab')">
            Lời mời <?php if($pendingCount > 0): ?><span class="badge"><?= $pendingCount ?></span><?php endif; ?>
        </button>
    </div>

    <div id="search-tab" class="tab-content active">
        <div class="search-card">
            <div class="search-box">
                <i class="material-symbols-outlined">search</i>
                <input type="text" id="q" placeholder="Nhập tên người dùng...">
            </div>
        </div>
        <div id="search-res"></div>
    </div>

    <div id="req-tab" class="tab-content">
        <?php foreach($requests as $r): ?>
            <div class="user-row" id="row-<?= $r['id'] ?>">
                <div class="u-info">
                    <div class="u-av">
                        <?php if(!empty($r['avatar'])): ?><img src="uploads/avatars/<?= $r['avatar'] ?>"><?php else: ?><?= strtoupper(substr($r['username'],0,1)) ?><?php endif; ?>
                    </div>
                    <div class="u-name"><?= htmlspecialchars($r['username']) ?></div>
                </div>
                <button class="action-btn btn-main" onclick="friendAction(<?= $r['id'] ?>, 'accept')">CHẤP NHẬN</button>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
    function switchTab(e, name) {
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.getElementById(name).classList.add('active');
        e.currentTarget.classList.add('active');
    }

    const qInp = document.getElementById('q');
    qInp.oninput = function() {
        if(this.value.length < 1) return;
        fetch('friend_logic.php?action=search&q=' + encodeURIComponent(this.value))
        .then(res => res.text())
        .then(data => { document.getElementById('search-res').innerHTML = data; });
    }

    function friendAction(targetId, type) {
        fetch(`friend_logic.php?action=${type}&id=${targetId}`)
        .then(res => res.json())
        .then(data => { if(data.success) location.reload(); });
    }
</script>
</body>
</html>
