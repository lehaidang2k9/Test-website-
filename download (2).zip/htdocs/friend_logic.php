<?php
require_once 'config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id'])) {
    die(json_encode(['success' => false, 'message' => 'Unauthorized']));
}

$my_id = $_SESSION['user_id'];
$action = $_GET['action'] ?? '';

// --- CHỨC NĂNG TÌM KIẾM ---
if ($action == 'search') {
    $q = "%" . ($_GET['q'] ?? '') . "%";
    
    // Tìm những người có tên khớp, trừ bản thân mình
    $stmt = $pdo->prepare("SELECT id, username, avatar FROM users WHERE username LIKE ? AND id != ? LIMIT 10");
    $stmt->execute([$q, $my_id]);
    $users = $stmt->fetchAll();

    if (!$users) {
        echo '<p style="text-align:center; color:#555; font-size:12px; margin-top:20px;">Không tìm thấy ai tên này</p>';
        exit;
    }

    foreach ($users as $u) {
        // Kiểm tra xem đã gửi lời mời hay là bạn bè chưa
        $st_check = $pdo->prepare("SELECT status FROM friends WHERE (user_id_1 = ? AND user_id_2 = ?) OR (user_id_1 = ? AND user_id_2 = ?)");
        $st_check->execute([$my_id, $u['id'], $u['id'], $my_id]);
        $relation = $st_check->fetch();

        echo '<div class="user-row">';
        echo '<div class="u-info">';
        echo '<div class="u-av">' . (!empty($u['avatar']) ? '<img src="uploads/avatars/'.$u['avatar'].'">' : strtoupper(substr($u['username'],0,1))) . '</div>';
        echo '<div class="u-name">' . htmlspecialchars($u['username']) . '</div>';
        echo '</div>';

        if (!$relation) {
            echo '<button class="action-btn btn-main" onclick="friendAction('.$u['id'].', \'add\')">KẾT BẠN</button>';
        } else {
            $status_text = ($relation['status'] == 'pending') ? 'ĐANG CHỜ' : 'BẠN BÈ';
            echo '<button class="action-btn" style="background:#222; color:#555" disabled>' . $status_text . '</button>';
        }
        echo '</div>';
    }
}

// --- CHỨC NĂNG GỬI LỜI MỜI ---
if ($action == 'add') {
    $target_id = $_GET['id'];
    $stmt = $pdo->prepare("INSERT IGNORE INTO friends (user_id_1, user_id_2, status) VALUES (?, ?, 'pending')");
    $res = $stmt->execute([$my_id, $target_id]);
    echo json_encode(['success' => $res]);
}

// --- CHỨC NĂNG CHẤP NHẬN ---
if ($action == 'accept') {
    $target_id = $_GET['id'];
    $stmt = $pdo->prepare("UPDATE friends SET status = 'accepted' WHERE user_id_1 = ? AND user_id_2 = ?");
    $res = $stmt->execute([$target_id, $my_id]);
    echo json_encode(['success' => $res]);
}
?>
