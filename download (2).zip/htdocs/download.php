<?php
require_once 'config.php';

$uuid = preg_replace('/[^a-f0-9]/i', '', $_GET['id'] ?? '');
if (empty($uuid)) { header('Location: /'); exit; }

$stmt = $pdo->prepare("SELECT * FROM files WHERE uuid = ?");
$stmt->execute([$uuid]);
$file = $stmt->fetch();

if (!$file) { header('HTTP/1.0 404 Not Found'); exit('File không tồn tại.'); }

$filePath = UPLOAD_DIR . $file['stored_name'];
if (!file_exists($filePath)) { header('HTTP/1.0 404 Not Found'); exit('File đã bị xóa.'); }

// Tăng download count
$pdo->prepare("UPDATE files SET download_count = download_count + 1 WHERE uuid = ?")->execute([$uuid]);

// Gửi file về đúng chất lượng gốc
$fsize = filesize($filePath);

// Hỗ trợ download từng phần (range request) cho video
$start = 0;
$end = $fsize - 1;

if (isset($_SERVER['HTTP_RANGE'])) {
    preg_match('/bytes=(\d+)-(\d*)/', $_SERVER['HTTP_RANGE'], $m);
    $start = intval($m[1]);
    if (!empty($m[2])) $end = intval($m[2]);
    header('HTTP/1.1 206 Partial Content');
    header('Content-Range: bytes ' . $start . '-' . $end . '/' . $fsize);
} else {
    header('HTTP/1.1 200 OK');
}

$length = $end - $start + 1;

header('Content-Type: ' . $file['mime_type']);
header('Content-Disposition: attachment; filename="' . rawurlencode($file['original_name']) . '"');
header('Content-Length: ' . $length);
header('Accept-Ranges: bytes');
header('Cache-Control: no-cache');
header('X-Content-Type-Options: nosniff');

$fp = fopen($filePath, 'rb');
fseek($fp, $start);

$bufSize = 8192;
$sent = 0;
while (!feof($fp) && $sent < $length) {
    $chunk = min($bufSize, $length - $sent);
    echo fread($fp, $chunk);
    $sent += $chunk;
    flush();
}
fclose($fp);
exit;
