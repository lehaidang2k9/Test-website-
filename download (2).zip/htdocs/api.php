<?php
// 1. Cấu hình & Kết nối
date_default_timezone_set('Asia/Ho_Chi_Minh');
require_once 'config.php';
if (session_status() === PHP_SESSION_NONE) session_start();

if (!isset($_SESSION['user_id'])) { exit('Cần đăng nhập'); }
$my_id = $_SESSION['user_id'];

// --- CHỨC NĂNG TẢI FILE: FIX LỖI "KHÔNG AN TOÀN" & "404" ---
if (isset($_GET['download'])) {
    $file = urldecode($_GET['download']);
    // Kiểm tra file tồn tại và đúng thư mục bảo mật
    if (strpos($file, 'uploads/chat/') === 0 && file_exists($file)) {
        
        // Xóa bộ đệm để file tải về không bị lỗi ký tự lạ
        if (ob_get_level()) ob_end_clean();

        $fileName = basename($file);
        
        // Headers ép trình duyệt tải xuống thay vì kiểm tra nội dung
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.$fileName.'"');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        
        readfile($file);
        exit;
    } else {
        header("HTTP/1.1 404 Not Found");
        exit('File không tồn tại trên hệ thống!');
    }
}

function timeAgo($timestamp) {
    $time = strtotime($timestamp); $diff = time() - $time;
    if ($diff < 30) return 'Vừa xong';
    $mins = floor($diff / 60);
    if ($mins < 60) return $mins . ' phút trước';
    return date('H:i d/m', $time);
}

$op = $_GET['op'] ?? '';

// --- UPLOAD CHUNK TỐC ĐỘ CAO ---
if ($op == 'upload_chunk') {
    $temp_dir = 'temp/' . $_POST['resumableIdentifier'];
    if (!is_dir($temp_dir)) mkdir($temp_dir, 0777, true);
    $chunk = $temp_dir . '/' . $_POST['resumableFilename'] . '.part' . $_POST['resumableChunkNumber'];
    move_uploaded_file($_FILES['file']['tmp_name'], $chunk);
    if (count(glob("$temp_dir/*.part*")) == $_POST['resumableTotalChunks']) {
        $final_dir = 'uploads/chat/';
        if (!is_dir($final_dir)) mkdir($final_dir, 0777, true);
        $path = $final_dir . time() . '_' . uniqid() . '.' . pathinfo($_POST['resumableFilename'], PATHINFO_EXTENSION);
        $dest = fopen($path, 'ab');
        for ($i = 1; $i <= $_POST['resumableTotalChunks']; $i++) {
            $p = "$temp_dir/" . $_POST['resumableFilename'] . ".part$i";
            fwrite($dest, file_get_contents($p)); unlink($p);
        }
        fclose($dest); rmdir($temp_dir);
        echo $path;
    }
    exit;
}

// --- DANH SÁCH BẠN BÈ ---
if ($op == 'list') {
    $stmt = $pdo->prepare("SELECT u.id, u.username, u.avatar FROM friends f JOIN users u ON (f.user_id_1 = u.id OR f.user_id_2 = u.id) WHERE (f.user_id_1 = ? OR f.user_id_2 = ?) AND u.id != ? AND f.status = 'accepted'");
    $stmt->execute([$my_id, $my_id, $my_id]);
    foreach($stmt->fetchAll() as $f) {
        $av = $f['avatar'] ? "uploads/avatars/".$f['avatar'] : "";
        $first = strtoupper(substr($f['username'], 0, 1));
        echo "<div class='chat-item' onclick='openBox({$f['id']}, \"{$f['username']}\", \"$av\", \"$first\")'>";
        echo "<div class='av-small'>".($av ? "<img src='$av'>" : $first)."</div>";
        echo "<div><b>{$f['username']}</b><br><small>Nhấn để nhắn tin</small></div></div>";
    }
    exit;
}

// --- TẢI TIN NHẮN (HIỂN THỊ MEDIA VÀ NÚT TẢI) ---
if ($op == 'load') {
    $fid = $_GET['fid'] ?? 0;
    $pdo->prepare("UPDATE messages SET status = 'seen' WHERE from_id = ? AND to_id = ? AND status != 'seen'")->execute([$fid, $my_id]);
    $stmt = $pdo->prepare("SELECT m.*, u.avatar, u.username FROM messages m JOIN users u ON m.from_id = u.id WHERE (m.from_id = ? AND m.to_id = ?) OR (m.from_id = ? AND m.to_id = ?) ORDER BY m.created_at ASC");
    $stmt->execute([$my_id, $fid, $fid, $my_id]);
    foreach($stmt->fetchAll() as $m) {
        $isMe = ($m['from_id'] == $my_id);
        $av_chat = $m['avatar'] ? "uploads/avatars/".$m['avatar'] : "";
        $fLetter = strtoupper(substr($m['username']??'U',0,1));
        echo "<div class='msg-row ".($isMe ? "me" : "")."'>";
        if(!$isMe) echo "<div class='av-chat'>".($av_chat ? "<img src='$av_chat'>" : $fLetter)."</div>";
        echo "<div class='bubble-wrap'><div class='bubble'>";
        
        // Kiểm tra xem tin nhắn có phải là đường dẫn file không
        if(strpos($m['message'], 'uploads/chat/') === 0) {
            $ext = strtolower(pathinfo($m['message'], PATHINFO_EXTENSION));
            $dl_url = "api.php?download=" . urlencode($m['message']);
            
            if(in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
                echo "<div class='mini-media'><img src='{$m['message']}' onclick='window.open(this.src)'><a href='$dl_url' class='mini-dl'>↓</a></div>";
            } else {
                echo "<div class='file-download-box'>
                        <span class='material-symbols-outlined'>movie</span>
                        <div style='flex:1; text-align:left'><b>Video .$ext</b><br><small>Nhấn nút để tải</small></div>
                        <a href='$dl_url' class='btn-dl-v2'>Tải về</a>
                      </div>";
            }
        } else {
            echo htmlspecialchars($m['message']);
        }
        
        echo "</div><div class='status'>".(($m['status']=='seen')?'Đã xem':'Đã gửi')." • ".timeAgo($m['created_at'])."</div></div></div>";
    }
    exit;
}

// --- GỬI TIN NHẮN ---
if ($op == 'send') {
    $to = $_POST['to'] ?? 0; $txt = trim($_POST['txt'] ?? '');
    if($to && $txt) {
        $stmt = $pdo->prepare("INSERT INTO messages (from_id, to_id, message, status, created_at) VALUES (?, ?, ?, 'sent', ?)");
        $stmt->execute([$my_id, $to, $txt, date('Y-m-d H:i:s')]);
    }
    exit;
}

$my_avatar = $_SESSION['avatar'] ?? '';
$my_username = $_SESSION['username'];
$my_firstLetter = strtoupper(substr($my_username, 0, 1));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>CloudX Messenger</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20,400,0,0" />
    <style>
        :root { --primary: #8b5cf6; --bg: #050508; --card: #111118; --border: rgba(255, 255, 255, 0.1); }
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: sans-serif; -webkit-tap-highlight-color: transparent; }
        body { background: var(--bg); color: #fff; height: 100vh; overflow: hidden; }
        .header { padding: 15px 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; background: rgba(17,17,24,0.8); backdrop-filter: blur(10px); }
        #friend-list { padding: 15px; height: calc(100vh - 140px); overflow-y: auto; }
        .chat-item { display: flex; align-items: center; gap: 12px; padding: 12px; background: var(--card); border-radius: 18px; margin-bottom: 10px; border: 1px solid var(--border); }
        .av-small { width: 45px; height: 45px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; overflow: hidden; }
        .av-small img { width: 100%; height: 100%; object-fit: cover; }
        #chat-window { position: fixed; inset: 0; background: var(--bg); z-index: 2000; display: none; flex-direction: column; }
        .chat-top { padding: 12px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 12px; }
        #msg-area { flex: 1; overflow-y: auto; padding: 15px; display: flex; flex-direction: column; gap: 12px; padding-bottom: 100px; }
        .msg-row { display: flex; gap: 8px; max-width: 85%; align-items: flex-end; }
        .msg-row.me { align-self: flex-end; flex-direction: row-reverse; }
        .av-chat { width: 28px; height: 28px; background: #333; border-radius: 50%; overflow: hidden; display: flex; align-items: center; justify-content: center; font-size: 10px; margin-bottom: 15px; }
        .av-chat img { width: 100%; height: 100%; object-fit: cover; }
        .bubble { padding: 8px 12px; border-radius: 18px; background: #1a1a25; font-size: 14px; border: 1px solid var(--border); word-break: break-word; }
        .me .bubble { background: var(--primary); border: none; }
        .status { font-size: 9px; color: #555; margin-top: 3px; }
        .mini-media { position: relative; width: 150px; height: 150px; margin-bottom: 5px; }
        .mini-media img { width: 100%; height: 100%; object-fit: cover; border-radius: 12px; }
        .mini-dl { position: absolute; bottom: 5px; right: 5px; background: rgba(0,0,0,0.7); color: #fff; width: 28px; height: 28px; border-radius: 50%; text-align: center; line-height: 28px; text-decoration: none; }
        .file-download-box { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 12px; border: 1px solid var(--border); min-width: 180px; }
        .btn-dl-v2 { background: var(--primary); color: #fff; text-decoration: none; padding: 6px 12px; border-radius: 8px; font-size: 12px; font-weight: bold; }
        .input-box { position: fixed; bottom: 0; width: 100%; padding: 10px 15px 30px; background: #000; display: flex; gap: 10px; align-items: center; border-top: 1px solid var(--border); }
        .input-box input { flex: 1; background: #111; border: 1px solid var(--border); color: #fff; padding: 10px 15px; border-radius: 20px; outline: none; }
        #prog-bar { position: absolute; top: 0; left: 0; height: 3px; background: var(--primary); width: 0%; transition: 0.2s; }
        .nav-bar { position: fixed; bottom: 0; left: 0; right: 0; background: #111; display: flex; justify-content: space-around; padding: 12px; border-top: 1px solid var(--border); z-index: 100; }
        .nav-item { color: #555; text-decoration: none; font-size: 10px; display: flex; flex-direction: column; align-items: center; }
        .nav-item.active { color: var(--primary); }
    </style>
</head>
<body>
<div class="header">
    <h1 style="font-size:18px">Hải Đăng <span style="color:var(--primary)">CloudX</span></h1>
    <div class="av-small"><?php if($my_avatar): ?><img src="uploads/avatars/<?=$my_avatar?>"><?php else: ?><?=$my_firstLetter?><?php endif; ?></div>
</div>
<div id="friend-list">Đang tải...</div>
<div id="chat-window">
    <div class="chat-top">
        <span class="material-symbols-outlined" onclick="closeBox()">arrow_back_ios</span>
        <div id="top-av" class="av-small" style="width:32px; height:32px; font-size:12px"></div>
        <b id="target-name"></b>
    </div>
    <div id="msg-area"></div>
    <div class="input-box">
        <div id="prog-bar"></div>
        <label style="cursor:pointer; color:#888"><span class="material-symbols-outlined">image</span><input type="file" id="fChat" hidden></label>
        <input type="text" id="minp" placeholder="Nhắn tin...">
        <button onclick="send()" style="background:none; border:none; color:var(--primary)"><span class="material-symbols-outlined">send</span></button>
    </div>
</div>
<nav class="nav-bar">
    <a href="index.php" class="nav-item"><span class="material-symbols-outlined">home</span>Trang chủ</a>
    <a href="api.php" class="nav-item active"><span class="material-symbols-outlined">chat</span>Tin nhắn</a>
    <a href="search.php" class="nav-item"><span class="material-symbols-outlined">group</span>Bạn bè</a>
    <a href="profile.php" class="nav-item"><span class="material-symbols-outlined">person</span>Hồ sơ</a>
</nav>

<script src="https://cdnjs.cloudflare.com/ajax/libs/resumable.js/1.1.0/resumable.min.js"></script>
<script>
    let currentTarget = 0, chatTimer = null;
    const r = new Resumable({ target: 'api.php?op=upload_chunk', chunkSize: 1*1024*1024 });
    r.assignBrowse(document.getElementById('fChat'));
    r.on('fileAdded', () => r.upload());
    r.on('progress', () => document.getElementById('prog-bar').style.width = (r.progress()*100)+'%');
    r.on('fileSuccess', (f, path) => { send(path); document.getElementById('prog-bar').style.width = '0%'; });

    function loadFriends() { fetch('api.php?op=list').then(r => r.text()).then(h => document.getElementById('friend-list').innerHTML = h); }
    function openBox(id, name, av, first) {
        currentTarget = id; document.getElementById('target-name').innerText = name;
        document.getElementById('top-av').innerHTML = av ? `<img src="${av}">` : first;
        document.getElementById('chat-window').style.display = 'flex';
        loadMsgs(); if(chatTimer) clearInterval(chatTimer); chatTimer = setInterval(loadMsgs, 3000);
    }
    function closeBox() { document.getElementById('chat-window').style.display = 'none'; clearInterval(chatTimer); }
    function loadMsgs() {
        if (!currentTarget) return;
        fetch(`api.php?op=load&fid=${currentTarget}`).then(r => r.text()).then(h => {
            const area = document.getElementById('msg-area');
            const isAtBottom = area.scrollTop + area.clientHeight >= area.scrollHeight - 100;
            area.innerHTML = h; if (isAtBottom) area.scrollTop = area.scrollHeight;
        });
    }
    function send(path = null) {
        const inp = document.getElementById('minp'), txt = path ? path : inp.value.trim();
        if(!txt || !currentTarget) return;
        let fd = new FormData(); fd.append('to', currentTarget); fd.append('txt', txt);
        fetch('api.php?op=send', { method: 'POST', body: fd }).then(() => { if(!path) inp.value = ''; loadMsgs(); });
    }
    window.onload = loadFriends;
</script>
</body>
</html>
