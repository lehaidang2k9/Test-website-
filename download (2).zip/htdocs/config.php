<?php
define('DB_HOST', 'sql311.infinityfree.com');
define('DB_NAME', 'if0_41666442_lehaidang');
define('DB_USER', 'if0_41666442');
define('DB_PASS', 'RD1sJTc7SQ');

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    die("Lỗi kết nối database: " . $e->getMessage());
}

// 1. Tự động tạo bảng users
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    avatar VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// 2. Tự động tạo bảng files
$pdo->exec("CREATE TABLE IF NOT EXISTS files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uuid VARCHAR(64) UNIQUE NOT NULL,
    user_id INT DEFAULT NULL,
    original_name VARCHAR(500) NOT NULL,
    stored_name VARCHAR(300) NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    file_size BIGINT NOT NULL,
    download_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// 3. TỰ ĐỘNG TẠO BẢNG TIN NHẮN & CẬP NHẬT CỘT FILE_PATH (QUAN TRỌNG)
$pdo->exec("CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_id INT NOT NULL,
    to_id INT NOT NULL,
    message TEXT DEFAULT NULL,
    file_path VARCHAR(255) DEFAULT NULL,
    status VARCHAR(20) DEFAULT 'sent',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

// Kiểm tra và tự động thêm cột file_path nếu nâng cấp từ bản cũ
try {
    $check = $pdo->query("SHOW COLUMNS FROM messages LIKE 'file_path'");
    if (!$check->fetch()) {
        $pdo->exec("ALTER TABLE messages ADD COLUMN file_path VARCHAR(255) DEFAULT NULL AFTER message");
    }
} catch (Exception $e) {}

// Kiểm tra và thêm cột status nếu thiếu
try {
    $checkStatus = $pdo->query("SHOW COLUMNS FROM messages LIKE 'status'");
    if (!$checkStatus->fetch()) {
        $pdo->exec("ALTER TABLE messages ADD COLUMN status VARCHAR(20) DEFAULT 'sent' AFTER file_path");
    }
} catch (Exception $e) {}

// 4. LỆNH CẬP NHẬT CẤU TRÚC KHÁC
try { $pdo->exec("ALTER TABLE users ADD COLUMN avatar VARCHAR(255) DEFAULT NULL AFTER password;"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE files ADD COLUMN user_id INT AFTER uuid;"); } catch (Exception $e) {}

// 5. QUẢN LÝ PHIÊN LÀM VIỆC
if (session_status() === PHP_SESSION_NONE) { 
    session_start(); 
}

function isLoggedIn() { 
    return isset($_SESSION['user_id']); 
}
?>
