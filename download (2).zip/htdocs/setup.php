<?php
// Kiểm tra nếu đã setup rồi thì chặn
if (file_exists('config.php') && defined('DB_NAME') && DB_NAME !== 'your_database_name') {
    // Nếu muốn dùng lại trang setup, xóa dòng này
    // header('Location: /'); exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hướng dẫn cài đặt MediaShare</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0a0a0f;color:#f0f0f5;font-family:'DM Sans',sans-serif;padding:2rem 1rem;line-height:1.7}
.wrap{max-width:700px;margin:0 auto}
h1{font-family:'Syne',sans-serif;font-size:2rem;font-weight:800;margin-bottom:0.5rem}
h1 span{color:#7c6fff}
.subtitle{color:#9090a8;margin-bottom:2.5rem}
h2{font-family:'Syne',sans-serif;font-size:1.1rem;font-weight:700;margin:2rem 0 0.75rem;color:#7c6fff}
.step{background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.07);border-radius:14px;padding:1.25rem 1.5rem;margin-bottom:1rem}
.step-num{display:inline-block;background:rgba(124,111,255,0.2);color:#b0a5ff;border-radius:8px;padding:2px 10px;font-size:0.78rem;font-weight:500;margin-bottom:0.5rem}
p{color:#9090a8;font-size:0.92rem;margin-bottom:0.6rem}
code{background:rgba(255,255,255,0.08);padding:2px 8px;border-radius:6px;font-size:0.85rem;color:#00e5c5;font-family:monospace}
pre{background:#12121a;border:1px solid rgba(255,255,255,0.07);border-radius:10px;padding:1rem;font-size:0.82rem;color:#c0c0d0;overflow-x:auto;margin:0.75rem 0;font-family:monospace;line-height:1.6}
.warn{background:rgba(255,200,0,0.06);border:1px solid rgba(255,200,0,0.2);border-radius:10px;padding:0.875rem 1rem;font-size:0.87rem;color:#ffd080;margin:1rem 0}
.ok{background:rgba(0,229,197,0.06);border:1px solid rgba(0,229,197,0.2);border-radius:10px;padding:0.875rem 1rem;font-size:0.87rem;color:#00e5c5;margin:1rem 0}
</style>
</head>
<body>
<div class="wrap">
<h1>Cài đặt <span>MediaShare</span></h1>
<p class="subtitle">Hướng dẫn từng bước để chạy website trên InfinityFree</p>

<div class="step">
<div class="step-num">Bước 1</div>
<h2>Tạo database MySQL trên InfinityFree</h2>
<p>Đăng nhập <strong>InfinityFree Panel</strong> → MySQL Databases → tạo database mới.</p>
<p>Ghi lại: <strong>tên database, username, password</strong> (chú ý: InfinityFree thêm prefix vào username).</p>
</div>

<div class="step">
<div class="step-num">Bước 2</div>
<h2>Chỉnh sửa config.php</h2>
<p>Mở file <code>config.php</code> và điền thông tin:</p>
<pre>define('DB_HOST', 'sql300.epizy.com');   // hoặc host InfinityFree cung cấp
define('DB_NAME', 'epiz_xxxxxxx_mediashare');
define('DB_USER', 'epiz_xxxxxxx');
define('DB_PASS', 'your_password');
define('SITE_URL', 'https://yourdomain.infinityfreeapp.com');</pre>
</div>

<div class="step">
<div class="step-num">Bước 3</div>
<h2>Upload tất cả file lên hosting</h2>
<p>Dùng <strong>File Manager</strong> trong InfinityFree Panel hoặc FTP (FileZilla) để upload toàn bộ folder lên <code>htdocs/</code>:</p>
<pre>htdocs/
├── index.php
├── view.php
├── upload.php
├── download.php
├── config.php
├── setup.php
├── .htaccess
└── uploads/          ← thư mục phải có quyền 755
    └── .htaccess</pre>
</div>

<div class="step">
<div class="step-num">Bước 4</div>
<h2>Phân quyền thư mục uploads</h2>
<p>Trong File Manager: chuột phải thư mục <code>uploads</code> → <strong>Change Permissions</strong> → đặt <code>755</code></p>
<div class="warn">⚠ Nếu uploads không có quyền ghi, file sẽ không lưu được.</div>
</div>

<div class="step">
<div class="step-num">Bước 5</div>
<h2>Truy cập website và thử nghiệm</h2>
<p>Mở <code>https://yourdomain.infinityfreeapp.com</code> — database sẽ được tạo tự động khi tải trang đầu tiên.</p>
<div class="ok">✓ Bảng <code>files</code> sẽ được tạo tự động khi kết nối database thành công.</div>
</div>

<div class="step">
<div class="step-num">Lưu ý quan trọng</div>
<h2>Giới hạn của InfinityFree</h2>
<p>• Upload tối đa khoảng <strong>10MB mỗi file</strong> (giới hạn PHP trên free hosting)</p>
<p>• Để upload file lớn hơn, cân nhắc dùng <strong>premium hosting</strong> hoặc implement <strong>chunked upload</strong></p>
<p>• InfinityFree có thể ngắt kết nối nếu script chạy quá lâu — với file nhỏ thì ổn</p>
<p>• Dung lượng lưu trữ: <strong>5GB</strong> (InfinityFree cung cấp)</p>
</div>

</div>
</body>
</html>
