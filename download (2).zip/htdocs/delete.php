<?php
require_once 'config.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['username'])) {
    echo json_encode(['status' => 'error', 'message' => 'Bạn chưa đăng nhập']);
    exit;
}

if (isset($_GET['uuid'])) {
    $uuid = $_GET['uuid'];

    // 1. Tìm thông tin file trong DB để lấy tên file vật lý
    $stmt = $pdo->prepare("SELECT stored_name FROM files WHERE uuid = ?");
    $stmt->execute([$uuid]);
    $file = $stmt->fetch();

    if ($file) {
        $filePath = 'uploads/' . $file['stored_name'];

        // 2. Xóa file vật lý trên ổ cứng
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // 3. Xóa bản ghi trong database
        $del = $pdo->prepare("DELETE FROM files WHERE uuid = ?");
        if ($del->execute([$uuid])) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Không thể xóa trong database']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Tệp không tồn tại']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Thiếu ID tệp']);
}
