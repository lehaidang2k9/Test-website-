<?php
require_once 'config.php';
if (!isLoggedIn()) { exit(json_encode(['success' => false, 'message' => 'Unauthorized'])); }

$temp_dir = 'temp_chunks';
$upload_dir = 'uploads';
if (!file_exists($temp_dir)) mkdir($temp_dir, 0777, true);
if (!file_exists($upload_dir)) mkdir($upload_dir, 0777, true);

$resumableIdentifier = $_POST['resumableIdentifier'] ?? '';
$resumableFilename   = $_POST['resumableFilename'] ?? '';
$resumableChunkNumber = $_POST['resumableChunkNumber'] ?? 1;
$resumableTotalChunks = $_POST['resumableTotalChunks'] ?? 1;

$customName = isset($_REQUEST['customName']) ? trim($_REQUEST['customName']) : '';
$extension = pathinfo($resumableFilename, PATHINFO_EXTENSION);
$finalOriginalName = !empty($customName) ? (pathinfo($customName, PATHINFO_EXTENSION) ? $customName : $customName . '.' . $extension) : $resumableFilename;

if (isset($_FILES['file']) && $_FILES['file']['error'] === 0) {
    $chunk_file = $temp_dir . '/' . $resumableIdentifier . '.part' . $resumableChunkNumber;
    if (move_uploaded_file($_FILES['file']['tmp_name'], $chunk_file)) {
        $total_on_server = 0;
        for ($i = 1; $i <= $resumableTotalChunks; $i++) {
            if (file_exists($temp_dir . '/' . $resumableIdentifier . '.part' . $i)) $total_on_server++;
        }

        if ($total_on_server == $resumableTotalChunks) {
            $uuid = bin2hex(random_bytes(16));
            $stored_name = $uuid . '.' . $extension;
            $final_path = $upload_dir . '/' . $stored_name;

            $dest = fopen($final_path, 'wb');
            for ($i = 1; $i <= $resumableTotalChunks; $i++) {
                $chunk_part = $temp_dir . '/' . $resumableIdentifier . '.part' . $i;
                $src = fopen($chunk_part, 'rb');
                stream_copy_to_stream($src, $dest);
                fclose($src); unlink($chunk_part);
            }
            fclose($dest);

            $stmt = $pdo->prepare("INSERT INTO files (uuid, user_id, original_name, stored_name, mime_type, file_size) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$uuid, $_SESSION['user_id'], $finalOriginalName, $stored_name, mime_content_type($final_path), filesize($final_path)]);

            echo json_encode(['success' => true, 'uuid' => $uuid]); exit;
        }
        echo json_encode(['success' => true]);
    }
}
?>
